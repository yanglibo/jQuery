<!DOCTYPE HTML>
<html>
<head>
	<!--
	<meta http-equiv="pragma" content="no-cache" />
	<meta http-equiv="cache-control" content="no-cache" />
	<meta http-equiv="expires" content="0" />
	-->
	<meta name="format-detection" content="telephone=no" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<meta name="format-detection" content="telephone=no" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>您所访问的页面不存在</title>
	<link rel="shortcut icon" href="//www.jd.com/favicon.ico"/>
	<link rel="icon" href="//www.jd.com/favicon.ico"/>
	<!--
	<link type="text/css" rel="stylesheet" href="//misc.360buyimg.com/lib/skin/2013/base.css" />
	<link type="text/css" rel="stylesheet"  href="//misc.360buyimg.com/??jdf/1.0.0/unit/ui-base/1.0.0/ui-base.css,jdf/1.0.0/unit/shortcut/2.0.0/shortcut.css,jdf/1.0.0/unit/global-header/1.0.0/global-header.css,jdf/1.0.0/unit/myjd/2.0.0/myjd.css,jdf/1.0.0/unit/nav/2.0.0/nav.css,jdf/1.0.0/unit/shoppingcart/2.0.0/shoppingcart.css,jdf/1.0.0/unit/global-footer/1.0.0/global-footer.css,jdf/1.0.0/unit/service/1.0.0/service.css,jdf/1.0.0/unit/basePatch/1.0.0/basePatch.css"/>
	-->
	<link type="text/css" rel="stylesheet" href="//misc.360buyimg.com/??jdf/1.0.0/unit/ui-base/1.0.0/ui-base.css,jdf/1.0.0/unit/shortcut/2.0.0/shortcut.css,jdf/1.0.0/unit/global-header/1.0.0/global-header.css,jdf/1.0.0/unit/myjd/2.0.0/myjd.css,jdf/1.0.0/unit/nav/2.0.0/nav.css,jdf/1.0.0/unit/shoppingcart/2.0.0/shoppingcart.css,jdf/1.0.0/unit/global-footer/1.0.0/global-footer.css,jdf/1.0.0/unit/service/1.0.0/service.css,jdf/1.0.0/unit/basePatch/1.0.0/basePatch.css,product/global/1.0.0/css/basePath.css">
	<link type="text/css" rel="stylesheet"  href="//misc.360buyimg.com/product/error/1.0.0/css/error.reco.css" source="combo"/>
	<script type="text/javascript" src="//misc.360buyimg.com/??jdf/lib/jquery-1.6.4.js,jdf/1.0.0/unit/base/1.0.0/base.js"></script>
	<link type="text/css" rel="stylesheet" href="//static.360buyimg.com/devfe/error-new/1.0.0/widget/??content/content.css" source="widget">
	<script type="text/javascript" src="//static.360buyimg.com/devfe/error-new/1.0.0/widget/??content/content.js" source="widget"></script>
</head>
<body>
<!--<script type="text/javascript" src="//misc.360buyimg.com/lib/js/2012/base-2011.js" charset="utf-8"></script>-->
<div id="shortcut-2014">
	<div class="w">
    	<ul class="fl">
    		<li class="dorpdown" id="ttbar-mycity"></li>
    	</ul>
    	<ul class="fr">
			<li class="fore1" id="ttbar-login">
				<a href="javascript:login();" class="link-login">你好，请登录</a>&nbsp;&nbsp;<a href="javascript:regist();" class="link-regist style-red">免费注册</a>
			</li>
			<li class="spacer"></li>
			<li class="fore2">
				<div class="dt">
					<a target="_blank" href="//order.jd.com/center/list.action">我的订单</a>
				</div>
			</li>
			<li class="spacer"></li>
			<li class="fore3 dorpdown" id="ttbar-myjd">
				<div class="dt cw-icon">
					<i class="ci-right"><s>◇</s></i>
					<a target="_blank" href="//home.jd.com/">我的京东</a>
				</div>
				<div class="dd dorpdown-layer"></div>
			</li>
			<li class="spacer"></li>
			<li class="fore4">
				<div class="dt">
					<a target="_blank" href="//vip.jd.com/">京东会员</a>
				</div>
			</li>
			<li class="spacer"></li>
			<li class="fore5">
				<div class="dt">
					<a target="_blank" href="//b.jd.com/">企业采购</a>
				</div>
			</li>
			<li class="spacer"></li>
			<li class="fore6 dorpdown" id="ttbar-apps">
				<div class="dt cw-icon">
					<i class="ci-left"></i>
					<i class="ci-right"><s>◇</s></i>
					<a target="_blank" href="//app.jd.com/">手机京东</a>
				</div>
			</li>
			<li class="spacer"></li>
			<li class="fore7 dorpdown" id="ttbar-atte">
				<div class="dt cw-icon">
					<i class="ci-right"><s>◇</s></i>关注京东
				</div>	
			</li>
			<li class="spacer"></li>
			<li class="fore8 dorpdown" id="ttbar-serv">
				<div class="dt cw-icon">
					<i class="ci-right"><s>◇</s></i>客户服务
				</div>
				<div class="dd dorpdown-layer"></div>
			</li>
			<li class="spacer"></li>
			<li class="fore9 dorpdown" id="ttbar-navs">
				<div class="dt cw-icon">
					<i class="ci-right"><s>◇</s></i>网站导航
				</div>
				<div class="dd dorpdown-layer"></div>
			</li>
    	</ul>
		<span class="clr"></span>
    </div>
</div>
<div id="o-header-2013"><div id="header-2013" style="display:none;"></div></div>
<div class="w">
    <div id="logo-2014">
    	<a href="//www.jd.com/" class="logo">京东</a>
    </div>
    <div id="search-2014" >
		<ul id="shelper" class="hide"></ul>
		<div class="form">
			<input type="text" onkeydown="javascript:if(event.keyCode==13) search('key');" autocomplete="off" id="key" accesskey="s" class="text" />
			<button onclick="search('key');return false;" class="button cw-icon"><i></i>搜索</button>
		</div>
    </div>
    <div id="settleup-2014" class="dorpdown">
		<div class="cw-icon">
			<i class="ci-left"></i>
			<i class="ci-right">&gt;</i>
			<a target="_blank" href="//cart.jd.com/cart.action">我的购物车</a>
		</div>
		<div class="dorpdown-layer">
			<div class="spacer"></div>
			<div id="settleup-content">
				<span class="loading"></span>
			</div>
		</div>
	</div>
    <div id="hotwords-2014"></div>
    <span class="clr"></span>
</div>
<div id="nav-2014">
    <div class="w">
        <div class="w-spacer"></div>
		<div id="categorys-2014" class="dorpdown"  data-type="default">
			<div class="dt">
				<a target="_blank" href="//www.jd.com/allSort.aspx">全部商品分类</a>
			</div>
		</div>
		<div id="navitems-2014">
			<ul id="navitems-group1">
				<li clstag="h|keycount|2015|06a" id="nav-fashion" class="fore1">
					<a target="_blank" href="//channel.jd.com/fashion.html">服装城</a>
				</li>
				<li clstag="h|keycount|2015|06b" id="nav-beauty" class="fore2">
					<a target="_blank" href="//channel.jd.com/beautysale.html">美妆馆</a>
				</li>
				<li clstag="h|keycount|2015|06c" id="nav-chaoshi" class="fore3">
					<a target="_blank" href="//channel.jd.com/chaoshi.html">超市</a>
				</li>
				<li clstag="h|keycount|2015|06i" id="nav-fresh" class="fore4">
					<a target="_blank" href="//fresh.jd.com">生鲜</a>
				</li>
			</ul>
			<div class="spacer"></div>
			<ul id="navitems-group2">
				<li clstag="h|keycount|2015|06d" id="nav-jdww" class="fore1">
					<a target="_blank" href="//www.jd.hk/">全球购</a>
				</li>
				<li clstag="h|keycount|2015|06e" id="nav-red" class="fore2">
					<a target="_blank" href="//red.jd.com/">闪购</a>
				</li>
				<li clstag="h|keycount|2015|06g" id="nav-auction" class="fore4">
					<a target="_blank" href="//paimai.jd.com/">拍卖</a>
				</li>
				<li clstag="h|keycount|2015|06h" id="nav-jr" class="fore5">
					<a target="_blank" href="//jr.jd.com/">金融</a>
				</li>
			</ul>
	    </div>
        <div id="treasure"></div>
        <span class="clr"></span>
    </div>
</div>
<!--
<div class="w">
	<div id="refresh">
		
	</div>
</div>
-->

<div class="w">
    
<!--  /widget/content/content.vm -->
<div class="content">
    <div class="content-l">
        <a href="//try.jd.com" target="_blank" clstag="pageclick|keycount|201601058|1">
            <img class="try-text" src="//static.360buyimg.com/devfe/error-new/1.0.0/css/i/try_03.png">
            <img class="try-img" src="//static.360buyimg.com/devfe/error-new/1.0.0/css/i/try1_07.png">
            <!-- <img class="try-text" src="../../../css/i/try_03.png">
            <img class="try-img" src="../../../css/i/try1_07.png"> -->
        </a>
    </div>
    <div class="content-m">
        <img src="//static.360buyimg.com/devfe/error-new/1.0.0/css/i/yinying_06.png">
        <!--<img src="../../../css/i/yinying_06.png">-->
    </div>
    <div class="content-r">
        <img class="error-img" src="//static.360buyimg.com/devfe/error-new/1.0.0/css/i/error_06.png">
        <!--<img class="error-img" src="../../../css/i/error_06.png">-->
        <p>抱歉!&nbsp;&nbsp;您访问的页面<span>失联</span>啦...</p>
        <span class="other">
            您可以逛逛&nbsp;&nbsp;:
            <a class="a-l" href="//www.jd.com" target="_blank" clstag="pageclick|keycount|201601058|2">
                京东首页
            </a>
             <a class="a-l" href="//try.jd.com" target="_blank" clstag="pageclick|keycount|201601058|3">
                京东试用
            </a>
            <a href="//vip.jd.com" target="_blank" clstag="pageclick|keycount|201601058|4">
                京东会员
            </a>
        </span>
    </div>
</div>
<!--/ /widget/content/content.vm -->
</div>


<div class="w">
    <div id="reco4u" class="m hide">
        <div class="mt">
            <h3>为你推荐</h3>
        </div>
        <div class="mc">
            <div class="loading-style1"><b></b>加载中，请稍候...</div>
            <!--{%widget name="ui-plist" data='{"cName": "lh", "width":"160", "height":"160", "num": "15", "color": "ddd"}'%}-->
        </div>
    </div><!-- reco4u -->
</div>
<div id="service-2014">
	<div class="slogen">
		<span class="item fore1">
			<i></i><b>多</b>品类齐全，轻松购物
		</span>
		<span class="item fore2">
			<i></i><b>快</b>多仓直发，极速配送
		</span>
		<span class="item fore3">
			<i></i><b>好</b>正品行货，精致服务
		</span>
		<span class="item fore4">
			<i></i><b>省</b>天天低价，畅选无忧
		</span>
	</div>
	<div class="w">
		<dl class="fore1">
			<dt>购物指南</dt>
			<dd>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-29.html">购物流程</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-151.html">会员介绍</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-297.html">生活旅行/团购</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue.html">常见问题</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-136.html">大家电</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/index.html">联系客服</a></div>
			</dd>
		</dl>
		<dl class="fore2">		
			<dt>配送方式</dt>
			<dd>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-81-100.html">上门自提</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-81.html">211限时达</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/103-983.html">配送服务查询</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/109-188.html">配送费收取标准</a></div>				
				<div><a target="_blank" href="//en.jd.com/chinese.html">海外配送</a></div>
			</dd>
		</dl>
		<dl class="fore3">
			<dt>支付方式</dt>
			<dd>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-172.html">货到付款</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-173.html">在线支付</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-176.html">分期付款</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-174.html">邮局汇款</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-175.html">公司转账</a></div>
			</dd>
		</dl>
		<dl class="fore4">		
			<dt>售后服务</dt>
			<dd>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/321-981.html">售后政策</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-132.html">价格保护</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/130-978.html">退款说明</a></div>
				<div><a rel="nofollow" target="_blank" href="//myjd.jd.com/repair/repairs.action">返修/退换货</a></div>
				<div><a rel="nofollow" target="_blank" href="//help.jd.com/user/issue/list-50.html">取消订单</a></div>
			</dd>
		</dl>
		<dl class="fore5">
			<dt>特色服务</dt>
			<dd>		
				<div><a target="_blank" href="//help.jd.com/user/issue/list-133.html">夺宝岛</a></div>
				<div><a target="_blank" href="//help.jd.com/user/issue/list-134.html">DIY装机</a></div>
				<div><a rel="nofollow" target="_blank" href="//fuwu.jd.com/">延保服务</a></div>
				<div><a rel="nofollow" target="_blank" href="//o.jd.com/market/index.action">京东E卡</a></div>				
				<div><a rel="nofollow" target="_blank" href="//mobile.jd.com/">京东通信</a></div>
				<div><a rel="nofollow" target="_blank" href="//s.jd.com/">京东JD+</a></div>
			</dd>
		</dl>
		<span class="clr"></span>
	</div>
</div>
<div class="w">
	<div id="footer-2014">
		<div class="links"><a rel="nofollow" target="_blank" href="//www.jd.com/intro/about.aspx">关于我们</a>|<a rel="nofollow" target="_blank" href="//www.jd.com/contact/">联系我们</a>|<a rel="nofollow" target="_blank" href="//www.jd.com/contact/joinin.aspx">商家入驻</a>|<a rel="nofollow" target="_blank" href="//jzt.jd.com">营销中心</a>|<a rel="nofollow" target="_blank" href="//app.jd.com/">手机京东</a>|<a target="_blank" href="//club.jd.com/links.aspx">友情链接</a>|<a target="_blank" href="//media.jd.com/">销售联盟</a>|<a href="//club.jd.com/" target="_blank">京东社区</a>|<a href="//sale.jd.com/act/FTrWPesiDhXt5M6.html" target="_blank">风险监测</a>|<a href="//gongyi.jd.com" target="_blank">京东公益</a>|<a href="//en.jd.com/" target="_blank">English Site</a>|<a href="//en.jd.com/help/question-58.html" target="_blank">Contact Us</a></div>
		<div class="copyright"><a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11000002000088"><img src="//img13.360buyimg.com/cms/jfs/t2293/321/1377257360/19256/c267b386/56a0a994Nf1b662dc.png" /> 京公网安备 11000002000088号</a>&nbsp;&nbsp;|&nbsp;&nbsp;京ICP证070359号&nbsp;&nbsp;|&nbsp;&nbsp;<a target="_blank" href="//img14.360buyimg.com/da/jfs/t256/349/769670066/270505/3b03e0bb/53f16c24N7c04d9e9.jpg">互联网药品信息服务资格证编号(京)-经营性-2014-0008</a>&nbsp;&nbsp;|&nbsp;&nbsp;新出发京零&nbsp;字第大120007号<br>互联网出版许可证编号新出网证(京)字150号&nbsp;&nbsp;|&nbsp;&nbsp;<a rel="nofollow" href="//img30.360buyimg.com/uba/jfs/t1036/328/1487467280/1405104/ea57ab94/5732f60aN53b01d06.jpg" target="_blank">出版物经营许可证</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="//misc.360buyimg.com/wz/wlwhjyxkz.jpg" target="_blank">网络文化经营许可证京网文[2014]2148-348号</a>&nbsp;&nbsp;|&nbsp;&nbsp;违法和不良信息举报电话：4006561155<br>Copyright&nbsp;&copy;&nbsp;2004-2016&nbsp;&nbsp;京东JD.com&nbsp;版权所有&nbsp;&nbsp;|&nbsp;&nbsp;消费者维权热线：4006067733<br>京东旗下网站：<a href="https://www.jdpay.com/" target="_blank">京东钱包</a>
		</div>		
		<div class="authentication">
			<a rel="nofollow" target="_blank" href="http://www.hd315.gov.cn/beian/view.asp?bianhao=010202007080200026">
				<img width="103" height="32" alt="经营性网站备案中心" src="//img12.360buyimg.com/da/jfs/t535/349/1185317137/2350/7fc5b9e4/54b8871eNa9a7067e.png" class="err-product" />
			</a>
			<script type="text/JavaScript">function CNNIC_change(eleId){var str= document.getElementById(eleId).href;var str1 =str.substring(0,(str.length-6));str1+=CNNIC_RndNum(6); document.getElementById(eleId).href=str1;}function CNNIC_RndNum(k){var rnd=""; for (var i=0;i < k;i++) rnd+=Math.floor(Math.random()*10); return rnd;}</script>
			<a rel="nofollow" target="_blank" id="urlknet" tabindex="-1" href="https://ss.knet.cn/verifyseal.dll?sn=2008070300100000031&ct=df&pa=294005">
				<img border="true" width="103" height="32" onclick="CNNIC_change('urlknet')" oncontextmenu="return false;" name="CNNIC_seal" alt="可信网站" src="//img11.360buyimg.com/da/jfs/t643/61/1174624553/2576/4037eb5f/54b8872dNe37a9860.png" class="err-product" />
			</a>
			<a rel="nofollow" target="_blank" href="http://www.bj.cyberpolice.cn/index.do">
				<img width="103" height="32" alt="网络警察" src="//img12.360buyimg.com/cms/jfs/t2050/256/1470027660/4336/2a2c74bd/56a89b8fNfbaade9a.jpg" class="err-product" />
			</a>
			<a rel="nofollow" target="_blank" href="https://search.szfw.org/cert/l/CX20120111001803001836">
				<img width="103" height="32" src="//img11.360buyimg.com/da/jfs/t451/173/1189513923/1992/ec69b14a/54b8875fNad1e0c4c.png" class="err-product" />
			</a>
			<a target="_blank" href="http://www.12377.cn"><img width="103" height="32" src="//img30.360buyimg.com/da/jfs/t1915/215/1329999964/2996/d7ff13f0/5698dc03N23f2e3b8.jpg"></a>
			<a target="_blank" href="http://www.12377.cn/node_548446.htm"><img width="103" height="32" src="//img14.360buyimg.com/da/jfs/t2026/221/2097811452/2816/8eb35b4b/5698dc16Nb2ab99df.jpg"></a>
		</div>
	</div>
</div>
<script type="text/javascript" src="//wl.jd.com/wl.js"></script>
<script>
	seajs.use('jdf/1.0.0/unit/category/2.0.0/category',function(category){
	    category({type:'home'});
	});
    seajs.config({
        charset:'utf-8'
    });
    seajs.config({
	    paths: {
	        'MISC': '//misc.360buyimg.com',
	        'APP_ROOT': '//static.360buyimg.com/devfe/error-new/1.0.0',
	        'WDG_ROO': '//static.360buyimg.com/devfe/error-new/1.0.0/widget',
	        'JDF_UI': '//misc.360buyimg.com/jdf/1.0.0/ui',
	        'JDF_UNIT': '//misc.360buyimg.com/jdf/1.0.0/unit'
	    }
	});
	seajs.use(['jdf/1.0.0/unit/globalInit/2.0.0/globalInit.js'],function(globalInit){
			globalInit();
		});
	seajs.use('APP_ROOT/js/error.reco', function(errorReco) {
	    errorReco();
	});
    //seajs.use(['//fa.360buy.com/loadFa_toJson.js?aid=2_697_5512', '//wl.jd.com/wl.js']);
    //seajs.use(['//nfa.jd.com/loadFa_toJson.action?aid=0_0_5512', '//wl.jd.com/wl.js']);
</script>

</body>
</html>
