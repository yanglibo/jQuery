var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?e32b0486ce2e2f6870da86b348af9816";
  var s = document.getElementsByTagName("script")[0];
  s.parentNode.insertBefore(hm, s);

})();
/*�ٶ�ͳ��*/

/*
var url = window.location;
if (url!="http://www.cr173.com/"){
//�ٶ�ͼƬ��� 
var cpro_id = "u2389090";
document.write('<script src="http://cpro.cr173.com/cpro/ui/i.js" type="text/javascript"></'+'script>')
}
*/

//baiduվ���Զ����ʹ���
(function(){
    var bp = document.createElement('script');
    bp.src = '//push.zhanzhang.baidu.com/push.js';
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();

function getBrowser(){
    var oType = "";
    if(navigator.userAgent.indexOf("MSIE")!=-1){
        oType="IE";
    }else if(navigator.userAgent.indexOf("Firefox")!=-1){
        oType="FIREFOX";
    }
    return oType;
}

function getPageCharset(){
    var charSet = "";
    var oType = getBrowser();
    switch(oType){
        case "IE":
            charSet = document.charset;
            break;
        case "FIREFOX":
            charSet = document.characterSet;
            break;
        default:
            break;
    }
    return charSet;
}

 //�Ƚ������ַ�����С����
function CompareDate(d1,d2)
{
  return ((new Date(d1.replace(/-/g,"\/"))) > (new Date(d2.replace(/-/g,"\/"))));
}

if ( typeof _webInfo != "undefined")
{
 var src = 'http://count.612.com//index.php?m=r'
    , charset = '&charset=' + getPageCharset()
    , atime = '&atime=' + _webInfo.DateTime // ��������ʱ��
    , ref = '&ref=' + encodeURIComponent(document.referrer)
    , url = '&url=' + encodeURIComponent(window.location.href)
    , username = '&username=' + encodeURIComponent(_webInfo.Username) // �û���
    , type = '&type=' +  _webInfo.Type // ����
	, rid ='&rid='+  _webInfo.Id //��ԴID
     , platform ='&platform=1' //ƽ̨pc=1��m��=2
    , content = '&content=' + encodeURIComponent(document.title);
   document.write('<iframe src="' + src + charset + atime + ref + url + username + type + rid  + platform + content + '" width="0" height="0" style="display:none;"></iframe>');
   if(CompareDate(_webInfo.DateTime,'2015/12/31')){
            var bjname=_webInfo.Username;
            var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");
            var _cnzzid,_cnzzsite;
            if(bjname!=''){
                switch (bjname){
                    case 'lilei':
                        _cnzzid=1260145133,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'cr173zhuwei':
                        _cnzzid=1259254879,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'hy_cr173':
                        _cnzzid=1257189736,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'liquan':
                        _cnzzid=1259255002,_cnzzsite='s11.cnzz.com';
                        break;
                    case 'zhongzai':
                        _cnzzid=1256652057,_cnzzsite='s11.cnzz.com';
                        break;
                    case 'zhengjin':
                        _cnzzid=1260137048,_cnzzsite='s11.cnzz.com';
                        break;
                    case 'cr173_zjj':
                        _cnzzid=1256652045,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'huyakun':
                        _cnzzid=1256652041,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'cr173hyj':
                        _cnzzid=1259255061,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'fanqiang':
                        _cnzzid=1259255027,_cnzzsite='s11.cnzz.com';
                        break;
                    case 'hjl':
                        _cnzzid=1256652029,_cnzzsite='s11.cnzz.com';
                        break;
                    case 'zhangwen':
                        _cnzzid=1256652022,_cnzzsite='s11.cnzz.com';
                        break;
                    case 'pengqi':
                        _cnzzid=1257189713,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'zhoubing':
                        _cnzzid=1256652011,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'luowen':
                        _cnzzid=1256652007,_cnzzsite='s11.cnzz.com';
                        break;
                    case 'zhongqiang':
                        _cnzzid=1256652001,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'shixing':
                        _cnzzid=1256651994,_cnzzsite='s11.cnzz.com';
                        break;
                    case 'thza':
                        _cnzzid=1256651988,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'lixinlong':
                        _cnzzid=1260137114,_cnzzsite='s11.cnzz.com';
                        break;
                    case 'zhangjia':
                        _cnzzid=1259257318,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'zhpc':
                        _cnzzid=1257189729,_cnzzsite='s11.cnzz.com';
                        break;
                    case 'liuxiaocong':
                        _cnzzid=1260137076,_cnzzsite='s95.cnzz.com';
                        break;
                    case 'lpp_cr173':
                        _cnzzid=1256651941,_cnzzsite='s95.cnzz.com';
                        break;
                    case 'oywx':
                        _cnzzid=1256651884,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'ganzhen':
                        _cnzzid=1256651837,_cnzzsite='s11.cnzz.com';
                        break;
                     case 'liuxiaoqing':
                        _cnzzid=1259255086,_cnzzsite='s95.cnzz.com';
                        break;
                      case 'yanwencai':
                        _cnzzid=1259257431,_cnzzsite='s95.cnzz.com';
                        break;
                    case 'fangyu':
                        _cnzzid=1259257460,_cnzzsite='s4.cnzz.com';
                        break;
                    case 'lujieming':
                        _cnzzid=1259257489,_cnzzsite='s11.cnzz.com';
                        break;  
                     case 'laiweiqiang':
                        _cnzzid=1260137150,_cnzzsite='s95.cnzz.com';
                        break;
                }
                if(typeof _cnzzid == 'number' && typeof _cnzzsite == 'string'){
                        document.write(unescape("%3Cspan id='cnzz_stat_icon_"+_cnzzid+"'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + _cnzzsite +"/stat.php%3Fid%3D"+_cnzzid+"%26show%3Dpic1' type='text/javascript'%3E%3C/script%3E"));
                }
            }
   }
}
//�����Զ����ʹ���
(function(){
   var src = document.location.protocol +'//js.passport.qihucdn.com/11.0.1.js?a47bc227fe250724e98e036d4ddfc443';
   document.write('<script src="' + src + '" id="sozz"><\/script>');
})();