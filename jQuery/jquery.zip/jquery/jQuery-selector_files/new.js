$(function(){
  //����ٶȷ���
   var bdfx = '<div class="bdsharebuttonbox fx f-cle"><a href="#" class="bds_more" data-cmd="more"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="������QQ�ռ�"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="����������΢��"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="��������Ѷ΢��"></a><a href="#" class="bds_renren" data-cmd="renren" title="������������"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="������΢��"></a></div>'
         $(".m-fs").prepend(bdfx);


//����ҳ�������
			var kpadstyle = '<style>.g-box-1240 {position:relative;z-index:10}#colbt:hover { background-position:left -30px}</style>'
	        var kpad = '<a href="http://www.cr173.com/azyx/255858.html" target="_blank" id="azbt" style="width:100%; height:1330px; display:block; position:absolute;top:156px;left:0; background:url(http://pic.cr173.com/skin/new2016/images/azbt.jpg) center 1px; z-index:1"></a>';
	        $("head").append(kpadstyle);
	        $("body").append(kpad);		
	        var btcol = '<a href="javascript:;" id="colbt" style=" width:30px; height:30px;background-image:url(http://pic.cr173.com//skin/new2016/images/colse.png); display:block;position:absolute;top:156px;right:0;z-index:2"></a>';
	        $("body").append(btcol);
	        $("#colbt").click(function(){
	        	$(this).hide();
	        	$("#azbt").hide();
	        });
//������

window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"24"},"share":{},"image":{"viewList":["qzone","tsina","tqq","renren","weixin"],"viewText":"��������","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];

  if(!placeholderSupport()){   // �ж�������Ƿ�֧��������� placeholder
      $('[placeholder]').focus(function() {
          var input = $(this);
          if (input.val() == input.attr('placeholder')) {
              input.val('');
              input.removeClass('placeholder');
          }
      }).blur(function() {
          var input = $(this);
          if (input.val() == '' || input.val() == input.attr('placeholder')) {
              input.addClass('placeholder');
              input.val(input.attr('placeholder'));
          }
      }).blur();
  };
  function placeholderSupport() {
      return 'placeholder' in document.createElement('input');
  }
  //ʹIE֧��placeholder����
//����Ч��
	$(".g-hide-nav .row .g-nav-cont:first").show();
  $(".g-nav li").hover(function(){
    $(this).addClass("m-hover");
  },function(){
    $(this).removeClass("m-hover");
  })
  var setTimer = "";
  $(".g-nav,.g-nav li,.g-hide-nav").hover(function(){
	clearTimeout(setTimer)
	setTimezk = setTimeout(function(){
    	if(!$(".g-hide-nav").is(":animated")){
			$(".g-hide-nav").show();
	 		$(".g-hide-nav").animate({height:380},280);
    	}
	},480);
  },function(){
	 clearTimeout(setTimezk)
 })
  	$(".g-nav li").hover(function(){
		clearTimeout(setTimer);
		var n = $(this).index();
		setTimehover = setTimeout(function(){
			$(".g-hide-nav").find(".g-nav-cont").eq(n).show().siblings(".g-nav-cont").hide();
		},160);
  	 },function(){
		clearTimeout(setTimehover);
	})
  $(".g-nav,.g-hide-nav").mouseleave(function(){
    setTimer = setTimeout(function(){
      $(".g-hide-nav").animate({height:0},280,function(){$(".g-hide-nav").hide();});
    },200);
  })
//��ȡ��ؿⲢ����������
var ku = $("#xgku").html()
 $("#content p:first").after(ku);
//������ʾ�Ҳ�
  $(window).scroll(function(){
            if($(window).scrollTop()>800){
            $(".g-fnav").show();
            }
            else{
                $(".g-fnav").hide();}
    });
  //������ʾH1

    $('.gotop').click(function(){
    $('html,body').animate({scrollTop:0},500);
    });
    //Kҳ��ѡ�
    $(".tab-btn li").hover(function(){
		var thisObj = $(this);
		setTimer = setTimeout(function(){
			thisObj.addClass("m-hover").siblings("li").removeClass("m-hover");
			var lien = thisObj.index();
			thisObj.parents(".tab-box").find(".tab-cont").eq(lien).show().siblings(".tab-cont").hide()
		},140)
	},function(){
		clearTimeout(setTimer)
	})
	$(".tab-box").each(function(index, element) {
		$(this).find(".tab-cont:gt(0)").hide()
	});
//����Ŵ�����С
    $(".fontsize a").click(function(){
        var thisEle = $("#content").css("font-size");
        var textFontSize = parseFloat(thisEle , 10);
        var unit = thisEle.slice(-2); //��ȡ��λ
        var cName = $(this).attr("class");
        if(cName == "bigger"){
        if( textFontSize <= 22 ){
        textFontSize += 2;
        }
        }else if(cName == "smaller"){
        if( textFontSize >= 12 ){
        textFontSize -= 2;
        }
        }
        $("#content").css("font-size", textFontSize + unit);
    });
//����Ч��   ��꾭������CSS�뿪ȥ��
    $(".f-hov").mouseover(function(){
        $(this).addClass("f-hover");
            }).mouseout(function(){
            $(this).removeClass("f-hover");
        });
        //�����������CSS��ʵ�ָ��л�ɫ
        $(".inswtable tr").each(function() {
            var index = $(this).index();
            if(!((index + 1) % 2)){
            $(this).addClass('m_liline');
            }
        });
        $(".inswtable tr").mouseover(function(){
        $(this).addClass("f-hover");
            }).mouseout(function(){
            $(this).removeClass("f-hover");
        });
        $(".inswtable tr:first").addClass("tr1");
        // ���е�  �����һ�� li �� f-ix�� ǰ���� li �� f-t3
        $('.f-top3').each(function() {
            $(this).find('li:first').addClass('f-ix').end()
            .find('li:eq(1)').addClass('f-t2');
           $(this).find('li:eq(2)').addClass('f-t3');
        })
        //��3��li��css,��0��ʼ
        $('.m-line4').each(function() {
            $(this).find('li:eq(2)').addClass('m-new-line');
        })
        //��ǰҳ�����е��ƽ������
        /*$("#xgrj").click(function(){
            var winH = $(window).height()/8;
            var keyT = $("#xgkey").offset().top;
            $("html,body").animate({scrollTop:keyT-winH-10},500);
         })*/

         $(".gozw").click(function(){$("html,body").animate({scrollTop:$('h1').offset().top}, 500);});
         $(".goxgxz").click(function(){$("html,body").animate({scrollTop:$('#xgkey').position().top-100}, 500);});
         $(".goxgwz").click(function(){$("html,body").animate({scrollTop:$('#xgnew').position().top-100}, 500);});
         $(".gopl").click(function(){$("html,body").animate({scrollTop:$('#ListMood').position().top-160}, 500);});

//û�����Kҳ��������
    var ksum = $('#xgkey ul').children('li').length;
    //console.log(ksum)
    if(ksum==0){
        $('#xgkey').hide();
        $('.xgrj').hide();
        $('#xgrj').hide();
        $('.goxgxz').parent("li").hide();
    }

  $(".g-introd-right dt em span").append($(".g-list-cont").length);
  $(".tab-btn li:first").addClass("m-hover");
  $("#foot .page_all p:first span:first").remove();
  $(".g-nav li").hover(function(){
    $(this).addClass("m-hover");
  },function(){
    $(this).removeClass("m-hover");
  })
  var boxSize = $(".g-left-box").length;
  if(boxSize>3){
    var titName = $(".g-left-box").eq(-3).find(".g-title dt").html();
    $(".g-left-box").eq(-3).remove();
    $(".g-left-box").eq(-2).find(".g-title dt").html(titName);
  }


  $(".g-list-cont").hover(function(){
    $(this).find("dt").stop().animate({top:0},200);
  },function(){
    $(this).find("dt").stop().animate({top:12},200);
  });

  $(".g-title dd a").click(function(){
    $(this).addClass("m-hover").siblings("a").removeClass("m-hover");
  })
});




if(PageClass==null)
{
  var PageClass=0;
}
//�������������
if( PageClass==4)
{
	$(function(){
		keyName();
    addweixin();
		 //Kҳ��ѡ�
		$(".tab-btn li").hover(function(){
			var thisObj = $(this);
			setTimer = setTimeout(function(){
				thisObj.addClass("m-hover").siblings("li").removeClass("m-hover");
				var lien = thisObj.index();
				thisObj.parents(".tab-box").find(".tab-cont").eq(lien).show().siblings(".tab-cont").hide()
			},140)
		},function(){
			clearTimeout(setTimer)
		})
		$(".tab-box").each(function(index, element) {
			$(this).find(".tab-cont:gt(0)").hide()
		});
	});
    //��ʾ��ͼ


            var $preview = $('<div id="image-preview"></div>').insertBefore("#foot").hide(), // ��insertBefore �Ƿ�ֹȥ���ʱ��ɾ
              imgLoaded = {}, // ����ͼƬ��ַ
              last = '', //��������Ƴ���ȡ��ͼƬ��ʾ�¼�
              mouse, // ������������¼�����
              showImg = function(img){
                position(img);
                $preview.empty().append(img.elem).show();
              },
              // ����Ͷ�λ
              position = function(img){

                // ��ʾ����Ӧ���� winWidth �� clinetX ����������� pageX�����ڿ��ȿ���С�� ��ҳ����
                var e = mouse,
                  $img = $(img.elem),
                  imgWidth = img.w,
                  imgHeight = img.h,
                  imgRate = imgWidth/imgHeight,

                  winWidth = $(window).width(),
                  winHeight = $(window).height(),
                  spaceX = 20,
                  spaceY = 15,
                  padding = 7, // ����
                  clientX = e.clientX,
                  clientY = e.clientY,
                  pageX = e.pageX,
                  pageY = e.pageY,

                  MINWIDTH = 300,
                  // �жϴ��ڿ���ʾ��������ֵ����������
                  maxWidth = Math.max(clientX -spaceX - padding*2, winWidth-clientX-spaceX - padding*2),

                  // ���ź�ĳߴ�
                  zoomWidth = imgWidth,
                  zoomHeight = imgHeight;


                maxWidth = Math.min(maxWidth,600);

                // ����ͼƬ
                if(imgWidth > maxWidth || imgHeight > winHeight){
                  if( imgRate > maxWidth / winHeight) {
                    zoomWidth = maxWidth;
                    zoomHeight = zoomWidth / imgRate;
                  } else {
                    zoomHeight = winHeight;
                    zoomWidth = zoomHeight * imgRate;
                  }

                }

                // ���ź�С����С���������µ���
                if(imgWidth > MINWIDTH  && zoomWidth < MINWIDTH){
                  zoomWidth = MINWIDTH;
                  zoomHeight = zoomWidth / imgRate;
                }


                //@return ������������
                //@do �ȼ�������ȼ�Ĺ�ϵ������״ֵ̬���ٸ���״̬ת����ʾλ�á�
                var pos = function(){

                  // Ϊ����ʾ�ϵ�ͳһ�ԣ�ֻ����������ʾ����
                  var xMode = clientX > winWidth / 2 ?  "left" : "right",
                    yMode;

                  if(winHeight - clientY - spaceY > zoomHeight ) yMode = "base"; //��ʾ������·�
                  else if ( winHeight >= zoomHeight ) yMode = "bottom"; // ���봰�ڵײ�
                  else yMode = "top" // ���봰�ڶ���


                  var x = {
                    right : pageX + spaceX ,
                    left: pageX - spaceX - zoomWidth - padding
                  }, y = {
                    base : pageY+ spaceY,
                    top : 0 ,
                    bottom : pageY - clientY + winHeight - zoomHeight - padding
                  };

                  return {
                    x : x[xMode],
                    y : y[yMode],
                    w : zoomWidth,
                    h : zoomHeight
                  }

                }()


                // Ӧ����ʽ
                $img.css({
                  width : pos.w,
                  height: pos.h
                });
                $preview.css({
                  left : pos.x,
                  top : pos.y
                });
              };


            $.fn.bigShow = function(rel){
                rel = rel || "preview"; // �����ͼ��ַ������

                this.hover(function(e){


                  var $this = $(this),
                    src = $this.attr(rel),
                    img = imgLoaded[src];

                   mouse = e;
                  last = src;

                  if(img){
                    showImg(img);
                  } else {
                    $("<img>").load(function(){

                      imgLoaded[src] = { elem : this , w: this.width, h : this.height };
                      if(last == src ) showImg(imgLoaded[src]);
                    }).attr("src",src);
                  }

                }, function(){
                  last = "";
                  $preview.hide();
                }).mousemove(function(e){

                  mouse = e;
                  var $this = $(this),
                  src = $this.attr(rel),
                  img = imgLoaded[src];

                  img && position(img);
            });
            }

            // ע����ʾ��ͼ�¼�
            $("a[preview]").bigShow();


}

//����������б�
if( PageClass==5)
{
    $(function(){
          //���صڶ�ҳ����ͼƬ
            var page = $(".tsp_count b").text();
            if( page == 1){
                      //��һҳʵ�е�Ч��
                      //ÿ3��LI����ǰ��LI
                        $(".m-listul li").each(function() {
                            var index = $(this).index();
                            if(!((index + 1) % 4)){
                              $(this).prev().prev().prev().before('<li class="xhli"><div class=""></div><p class=""></p></li>');
                            }
                          });
                        //��3�������������ӱ���
                          $(".m-listul li.xhli div").text("��������");
                          $(".m-listul li.xhli:first div").text("�Ƽ�����");
                          $(".m-listul li.xhli:eq(1) div").text("��������");
                          $(".m-listul li.xhli:eq(2) div").text("�༭��ѡ");

                          //��1ҳ��9��������
                         //$('.m-listul').each(function() {!$(this).find('li:gt(11)').hide();})

                         //�����ͼƬ����ʾ
                          $('.m-listright ul li em img').each(function() {
                               if($(this).attr("src")== '/skin/logo.gif'){
                             }else{
                              $(this).parents("em").show();
                             }
                    });
                    //����ͼƬ���ᵽ��һ������
                   var nextLi =$(".xhli").nextUntil(".xhli")
                      nextLi.each(function(){
                        var liHide = $(this).css("display");
                        var imgSize = $(this).find("img").length;
                        var imgUrl = $(this).find("img").attr("src");
                        if(imgSize>0 && imgUrl != "/skin/logo.gif" && liHide != "none"){
                          var youImg = '<li class="f-hov">' + $(this).html() + '</li>';
                          $(this).prevAll(".xhli").eq(0).after(youImg);
                          $(this).remove();
                        }
                      });



        }else
        {
          //����һҳ
          $(".m-listul li em").hide();
        }
        //���������˵��̶�
        $(window).scroll(function(){
            if($(window).scrollTop()>196){
            $(".m-leftdiv1").addClass("lefttop");
            }
            else{
                $(".m-leftdiv1").removeClass("lefttop");}
         });
        //������ʾ���ض���
         var gotop = '<div id="roll"><a title="�ض���" id="roll_top" href="javascript:;" style="display: ;">TOP</a></div>';
         $("body").append(gotop);
         $(window).scroll(function(){
            if($(window).scrollTop()>300){

              $("#roll_top").show(300);
            }
            else{
                $("#roll_top").hide();}
         });
         $("#roll_top").click(function(){$("html,body").animate({scrollTop:$('body').offset().top}, 500);});
    });
}

function keyName(){
	//��ȡKҳ������������
	var themeTitle = "";
	$("#xiangua .xiangualist").each(function(){
		themeTitle += '<li>'+$(this).find("dl dd:first a").text().replace(/\s+/g,'');+'</li>';
	})
	$("#xiangua .xianguatitle").html(themeTitle);
	$("#xiangua .xianguatitle li:first").addClass("m-hover");
	//��ȡK
	var floatCont = "";
	var keyHtml = "";
	var keySize = $(".xianguatitle li").length;
	if(keySize>0){
		$("#xiangua .xiangualist").each(function(){
			var keyText = $(this).find("dl dd:first a").text().replace(/\s+/g,'');
			keyHtml += '<b>'+ keyText + '</b>'
		})
		var keyLink = keyHtml;
		$("#taggo").append(keyLink);
		if($(".m-xgsoft").length>0){
			var h1Cont = $("h1").html();
			var kName = $("#taggo").html();
			var img = $("#m-float-img").html();
			var name = $("#m-float-name").html();
			var url = $("#m-soft-url").attr("href");
      var gozturl = $(".gozt").attr("href");
      console.log(gozturl)
      if(gozturl != undefined ){
  			floatCont = '<div class="m-float-cont clearfix"><div class="f-fl hleft">'+ '<h1>' + h1Cont + '</h1>'+'<p>'+'<a href="'+ gozturl +'" target="_blank" class="topgozt">'+ "ǰ��ר��" +'</a>' + img +'<strong>'+'<a href="'+ url +'" target="_blank">'+ name +'</a>'+'</strong>'+ '<i>'+ "��ǩ��" +'</i>' + '<span id="taggoF">'+kName+'</span>'+'</p>' +'</div><div class="f-fr hright"><a href="'+ url +'" class="m-abtn">'+ name +'</a></div></div>'
      }else{
        floatCont = '<div class="m-float-cont clearfix"><div class="f-fl hleft">'+ '<h1>' + h1Cont + '</h1>'+'<p>' + img +'<strong>'+'<a href="'+ url +'" target="_blank">'+ name +'</a>'+'</strong>'+ '<i>'+ "��ǩ��" +'</i>' + '<span id="taggoF">'+kName+'</span>'+'</p>' +'</div><div class="f-fr hright"><a href="'+ url +'" class="m-abtn">'+ name +'</a></div></div>'
      }
      $("body").append(floatCont);
		}else{
			var h1Cont = $("h1").html();
			var kName = $("#taggo").html();
			//var img = $("#m-float-img").html();
			//var name = $("#m-float-name").html();
			floatCont = '<div class="m-float-cont">'+ '<h1>' + h1Cont + '</h1>'+'<p>' + '<i>'+ "��ǩ��" +'</i>' + '<span id="taggoF">'+kName+'</span>'+'</p>' +'</div>'
			$("body").append(floatCont)
		}
		$("#taggoF b").hover(function(){
			$(this).addClass("m-hover").siblings("b").removeClass("m-hover");
		},function(){
			$(this).removeClass("m-hover");
		})
		$(window).scroll(function(){
			var h1Top = $(".m-h1-float").offset().top;
			if($(window).scrollTop()>h1Top){
				$(".m-float-cont").fadeIn("fast")
			}else{
				$(".m-float-cont").fadeOut("fast")
			}
		});
	  	$("#taggo,#taggoF").find("b").click(function(){
		var winHeight = $(window).height()/5;
		var keyTop = $("#xiangua").offset().top;
		$("html,body").animate({scrollTop:keyTop-winHeight-86},150);
		var n = $(this).index();
		$("#xiangua").find(".tab-btn li").eq(n).addClass("m-hover").siblings("li").removeClass("m-hover");
		$("#xiangua").find(".tab-cont").eq(n).show().siblings(".tab-cont").hide();
	  })
	}
}
function addweixin(){//��ȡҳ��ؼ������Ӷ�ά��2016-10-22

        var metas = document.getElementsByTagName("meta"); 
        var keysmun = metas[0].content.indexOf(",")
        if(metas[0].content.indexOf(",") != -1){
                metas = metas[0].content.substr(0,keysmun)
        }else{
            metas = metas[0].content
        }


        console.log(metas)    
        console.log(keysmun)
        //�ж���Ŀ���Ӷ�ά��.

        //var wxhao = '<div style="display:none;text-align: center;width: 900px;height: 200px;background: url(http://pic.cr173.com/skin/new2015/images/weixinbg.jpg/);margin: 0 auto;color: #fff;font-family: "microsoft yahei";"><p style="font-size: 22px;width: 400px;margin: 30px 0 0 10px;height: 30px;line-height: 30px;overflow: hidden;float: left;display: inline;">����<span class="color: #EEFF2F;font-size: 24px;">'+metas+'</span>֪ʶ����ע΢�Ź��ں�</p><p style="width: 100px;    font-size: 18px;margin: 20px 5px 0 0;">΢�Ź��ں�<br>�����ֻ�վ</p></div>';   
        var wxhao = '<div style="text-align: center;width:900px;height: 200px;background: url(http://pic.cr173.com/skin/new2015/images/weixinbg.jpg) no-repeat center center #fff;margin: 0 auto 10px;color: #fff;"></div>'; 
        $(".m-leftdiv:last").before(wxhao);


}